-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 10 apr 2022 om 21:32
-- Serverversie: 10.4.22-MariaDB
-- PHP-versie: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `log`
--

CREATE TABLE `log` (
  `logid` int(11) NOT NULL,
  `websiteid` int(11) NOT NULL,
  `statusid` int(11) NOT NULL,
  `logdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `log`
--

INSERT INTO `log` (`logid`, `websiteid`, `statusid`, `logdate`) VALUES
(117, 1, 0, '2022-04-10 19:31:18'),
(118, 2, 1, '2022-04-10 19:31:18'),
(119, 3, 1, '2022-04-10 19:31:19'),
(120, 1, 0, '2022-04-10 19:31:23'),
(121, 2, 1, '2022-04-10 19:31:23'),
(122, 3, 1, '2022-04-10 19:31:23'),
(123, 1, 0, '2022-04-10 19:31:43'),
(124, 2, 1, '2022-04-10 19:31:43'),
(125, 3, 1, '2022-04-10 19:31:44'),
(126, 1, 0, '2022-04-10 19:31:45'),
(127, 2, 1, '2022-04-10 19:31:45'),
(128, 3, 1, '2022-04-10 19:31:45'),
(129, 1, 0, '2022-04-10 19:31:46'),
(130, 2, 1, '2022-04-10 19:31:46'),
(131, 3, 1, '2022-04-10 19:31:46');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `new_record`
--

CREATE TABLE `new_record` (
  `id` int(11) NOT NULL,
  `trn_date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `trn_date`, `submittedby`) VALUES
(1, 'joan', 'joan@test.com', '098f6bcd4621d373cade4e832627b4f6', '2022-04-07 12:11:56', 'test');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `website`
--

CREATE TABLE `website` (
  `id` int(11) NOT NULL,
  `usersid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `interval` int(10) NOT NULL,
  `timeout` int(10) NOT NULL,
  `email` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `website`
--

INSERT INTO `website` (`id`, `usersid`, `name`, `url`, `interval`, `timeout`, `email`) VALUES
(1, 1, 'Google.ik', 'google.ik', 15, 30, 'joan@test.com'),
(2, 1, 'Google.com', 'google.com', 15, 30, 'joan@test.com'),
(3, 1, 'Bit Academy', 'https://nlleertdoor.bit-academy.nl', 15, 30, 'joan@test.com');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`logid`);

--
-- Indexen voor tabel `new_record`
--
ALTER TABLE `new_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `website`
--
ALTER TABLE `website`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `log`
--
ALTER TABLE `log`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT voor een tabel `new_record`
--
ALTER TABLE `new_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `website`
--
ALTER TABLE `website`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
