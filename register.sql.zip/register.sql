-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 07 apr 2022 om 23:58
-- Serverversie: 10.4.22-MariaDB
-- PHP-versie: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `log`
--

CREATE TABLE `log` (
  `logid` int(11) NOT NULL,
  `websiteid` int(11) NOT NULL,
  `statusid` int(11) NOT NULL,
  `logdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `log`
--

INSERT INTO `log` (`logid`, `websiteid`, `statusid`, `logdate`) VALUES
(1, 3, 0, '2022-04-07 16:07:20'),
(2, 1, 0, '2022-04-07 16:08:46'),
(3, 2, 1, '2022-04-07 16:08:47'),
(4, 3, 0, '2022-04-07 16:08:47'),
(5, 1, 1, '2022-04-07 16:11:10'),
(6, 2, 1, '2022-04-07 16:11:10'),
(7, 3, 1, '2022-04-07 16:11:11'),
(8, 1, 1, '2022-04-07 16:19:44'),
(9, 2, 1, '2022-04-07 16:19:44'),
(10, 3, 1, '2022-04-07 16:19:45'),
(11, 1, 1, '2022-04-07 16:22:44'),
(13, 3, 1, '2022-04-07 16:22:45'),
(17, 1, 1, '2022-04-07 21:10:59'),
(18, 2, 1, '2022-04-07 21:10:59'),
(19, 3, 1, '2022-04-07 21:11:00'),
(20, 1, 1, '2022-04-07 21:13:16'),
(21, 2, 1, '2022-04-07 21:13:16'),
(22, 3, 1, '2022-04-07 21:13:16'),
(23, 1, 1, '2022-04-07 21:14:23'),
(24, 2, 1, '2022-04-07 21:14:23'),
(25, 3, 1, '2022-04-07 21:14:23'),
(26, 1, 1, '2022-04-07 21:14:51'),
(27, 2, 1, '2022-04-07 21:14:51'),
(28, 3, 1, '2022-04-07 21:14:51'),
(29, 1, 1, '2022-04-07 21:16:36'),
(30, 2, 1, '2022-04-07 21:16:36'),
(31, 3, 1, '2022-04-07 21:16:36'),
(32, 1, 1, '2022-04-07 21:17:04'),
(33, 2, 1, '2022-04-07 21:17:04'),
(34, 3, 1, '2022-04-07 21:17:04'),
(35, 1, 1, '2022-04-07 21:45:02'),
(36, 2, 1, '2022-04-07 21:45:02'),
(37, 3, 1, '2022-04-07 21:45:02'),
(38, 1, 1, '2022-04-07 21:45:27'),
(39, 2, 1, '2022-04-07 21:45:27'),
(40, 3, 1, '2022-04-07 21:45:27'),
(41, 1, 1, '2022-04-07 21:56:37'),
(42, 2, 1, '2022-04-07 21:56:37'),
(43, 3, 1, '2022-04-07 21:56:37');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `new_record`
--

CREATE TABLE `new_record` (
  `id` int(11) NOT NULL,
  `trn_date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `trn_date`, `submittedby`) VALUES
(1, 'joan', 'joan.puts@gmail.com', '098f6bcd4621d373cade4e832627b4f6', '2022-04-07 12:11:56', 'test');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `website`
--

CREATE TABLE `website` (
  `id` int(11) NOT NULL,
  `usersid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `interval` int(10) NOT NULL,
  `timeout` int(10) NOT NULL,
  `email` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `website`
--

INSERT INTO `website` (`id`, `usersid`, `name`, `url`, `interval`, `timeout`, `email`) VALUES
(1, 1, 'Light 04', 'm2light04.r2retail.com/pub/health_check.php', 15, 30, 'jputs@r2retail.com'),
(2, 1, 'Light 05', 'm2light05.r2retail.com/pub/health_check.php', 15, 30, 'jputs@r2retail.com'),
(3, 5, 'Light 03', 'm2light04.r2retail.com/pub/health_check.php', 15, 30, 'jputs@r2retail.com');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`logid`);

--
-- Indexen voor tabel `new_record`
--
ALTER TABLE `new_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `website`
--
ALTER TABLE `website`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `log`
--
ALTER TABLE `log`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT voor een tabel `new_record`
--
ALTER TABLE `new_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
